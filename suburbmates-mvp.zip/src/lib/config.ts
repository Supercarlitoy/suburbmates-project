export const SITE={name:'SuburbMates',city:'Melbourne',feePercent:10}
