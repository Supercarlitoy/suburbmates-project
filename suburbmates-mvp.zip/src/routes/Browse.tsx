import TaskCard from '@/components/TaskCard'
export default function Browse(){
  const tasks=[{id:'1',title:'Assemble flat-pack shelves',suburb:'Fitzroy',budget:80,posted:'2h ago'},{id:'2',title:'Dog walking this weekend',suburb:'Brunswick',budget:30,posted:'4h ago'}]
  return (
    <div className="mx-auto max-w-6xl px-4 py-6">
      <div className="sticky top-14 bg-gray-50 py-2">
        <div className="flex gap-2">
          <select className="border rounded-xl px-3 py-2"><option>All Suburbs</option></select>
          <select className="border rounded-xl px-3 py-2"><option>All Categories</option></select>
          <label className="flex items-center gap-2 text-sm"><input type="checkbox"/> Verified-only</label>
        </div>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
        {tasks.map(t => <TaskCard key={t.id} task={t as any} />)}
      </div>
    </div>
  )
}
