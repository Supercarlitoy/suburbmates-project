import { POLICY } from '@/lib/policies'
export default function Terms(){
  return (
    <div className="mx-auto max-w-3xl px-4 py-6 prose">
      <h1>Terms & Neighbourly Rules</h1>
      <h2>Confidentiality</h2><ul>{POLICY.confidentiality.map((x,i)=><li key={i}>{x}</li>)}</ul>
      <h2>Bidding</h2><ul>{POLICY.bidding.map((x,i)=><li key={i}>{x}</li>)}</ul>
      <h2>Payments</h2><ul>{POLICY.payments.map((x,i)=><li key={i}>{x}</li>)}</ul>
      <h2>Payouts</h2><ul>{POLICY.payout.map((x,i)=><li key={i}>{x}</li>)}</ul>
    </div>
  )
}
