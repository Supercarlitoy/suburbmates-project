export default function AdminOffers(){return(<div className='bg-white border rounded-2xl p-4'>Offer table…</div>)}
