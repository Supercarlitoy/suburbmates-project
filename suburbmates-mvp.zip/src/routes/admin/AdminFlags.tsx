export default function AdminFlags(){return(<div className='bg-white border rounded-2xl p-4'>Moderation queue…</div>)}
