import { Routes, Route, Link } from 'react-router-dom'
function Inbox(){return(<div className="space-y-3"><Link to="t/1" className="block bg-white border rounded-xl p-3">Chat with maria — “See you Saturday!”</Link></div>)}
function Thread(){return(<div className="flex flex-col gap-3"><div className="self-start bg-white border rounded-2xl px-3 py-2">Hi! Happy to help.</div><div className="self-end bg-brand-primary text-white rounded-2xl px-3 py-2">Amazing, thanks!</div><div className="mt-2"><input className="w-full border rounded-xl px-3 py-2" placeholder="Type a neighbourly message…"/></div></div>)}
export default function Messages(){return(<div className="mx-auto max-w-3xl px-4 py-6"><Routes><Route index element={<Inbox/>}/><Route path="t/:id" element={<Thread/>}/></Routes></div>)}
