import { useParams } from 'react-router-dom'
export default function PublicProfile(){
  const { username } = useParams()
  return (
    <div className="mx-auto max-w-3xl px-4 py-6">
      <div className="flex items-center gap-4">
        <div className="w-16 h-16 rounded-full bg-gradient-to-br from-brand-primary to-brand-accent" />
        <div>
          <h1 className="text-xl font-bold">{username}</h1>
          <div className="text-sm text-gray-600">Fitzroy • ✓ Verified Neighbour</div>
        </div>
      </div>
      <section className="mt-6">
        <h2 className="font-semibold mb-2">Thank‑You Notes</h2>
        <div className="bg-white p-4 rounded-2xl border">“Job well done!” — Alex</div>
      </section>
    </div>
  )
}
