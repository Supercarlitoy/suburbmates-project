import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { TaskSchema } from '@/utils/validation'

export default function NewTask(){
  const { register, handleSubmit, formState:{errors} } = useForm({ resolver: zodResolver(TaskSchema as any) })
  const onSubmit = (data:any)=> alert('Posted!\n'+JSON.stringify(data,null,2))
  return (
    <div className="mx-auto max-w-xl px-4 py-6">
      <h1 className="text-xl font-bold mb-4">Ask for a Hand</h1>
      <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
        <div>
          <label className="block text-sm font-medium">Title</label>
          <input {...register('title')} className="mt-1 w-full border rounded-xl px-3 py-2" placeholder="e.g., Mow small backyard"/>
          {errors.title && <p className="text-red-600 text-sm">{String(errors.title.message)}</p>}
        </div>
        <div>
          <label className="block text-sm font-medium">Description</label>
          <textarea {...register('description')} className="mt-1 w-full border rounded-xl px-3 py-2" rows={5}/>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-sm font-medium">Category</label>
            <input {...register('category')} className="mt-1 w-full border rounded-xl px-3 py-2" placeholder="Repairs"/>
          </div>
          <div>
            <label className="block text-sm font-medium">Suburb</label>
            <input {...register('suburb')} className="mt-1 w-full border rounded-xl px-3 py-2" placeholder="Fitzroy"/>
          </div>
        </div>
        <div>
          <label className="block text-sm font-medium">Budget (AUD)</label>
          <input type="number" {...register('budget', { valueAsNumber: true })} className="mt-1 w-full border rounded-xl px-3 py-2" placeholder="80"/>
        </div>
        <button className="w-full px-4 py-2 rounded-xl bg-brand-primary text-white">Post Task</button>
      </form>
    </div>
  )
}
