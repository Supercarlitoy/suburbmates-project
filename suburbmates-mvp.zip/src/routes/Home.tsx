import { Link } from 'react-router-dom'
import TaskCard from '@/components/TaskCard'
import ProfileCard from '@/components/ProfileCard'

export default function Home(){
  const tasks=[{id:'1',title:'Assemble flat-pack shelves',suburb:'Fitzroy',budget:80,posted:'2h ago'},{id:'2',title:'Dog walking this weekend',suburb:'Brunswick',budget:30,posted:'4h ago'}]
  const people=[{username:'maria',suburb:'Carlton',verified:true},{username:'james',suburb:'Northcote',verified:false}]
  return (
    <div className="mx-auto max-w-6xl px-4 py-6">
      <section className="text-center py-8">
        <h1 className="text-2xl font-bold">Find a trusted neighbour to give you a hand.</h1>
        <p className="mt-2 text-gray-600">Local, friendly, and secure — built for Melbourne suburbs.</p>
        <div className="mt-4 flex gap-3 justify-center">
          <Link to="/tasks/new" className="px-4 py-2 rounded-xl bg-brand-primary text-white">Ask for a Hand</Link>
          <Link to="/browse" className="px-4 py-2 rounded-xl border">See Who’s Helping Out</Link>
        </div>
      </section>
      <section className="py-4">
        <h2 className="font-semibold mb-3">Featured Verified Neighbours</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {people.map(p => <ProfileCard key={p.username} p={p as any} />)}
        </div>
      </section>
      <section className="py-4">
        <h2 className="font-semibold mb-3">Latest Local Tasks</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {tasks.map(t => <TaskCard key={t.id} task={t as any} />)}
        </div>
      </section>
    </div>
  )
}
