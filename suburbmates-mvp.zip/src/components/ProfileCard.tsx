import { Link } from 'react-router-dom'
export default function ProfileCard({p}:{p:{username:string,suburb:string,verified?:boolean}}){
  return (
    <Link to={`/u/${p.username}`} className="block bg-white rounded-2xl shadow-sm border p-4 hover:shadow-md transition">
      <div className="flex items-center gap-3">
        <div className="w-12 h-12 rounded-full bg-gradient-to-br from-brand-primary to-brand-accent" />
        <div>
          <div className="font-semibold">{p.username} {p.verified && <span className="ml-1 text-xs text-brand-primary">✓ Verified Neighbour</span>}</div>
          <div className="text-sm text-gray-600">{p.suburb}</div>
        </div>
      </div>
    </Link>
  )
}
