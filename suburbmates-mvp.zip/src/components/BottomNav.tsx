import { Link, useLocation } from 'react-router-dom'
export default function BottomNav(){
  const { pathname } = useLocation()
  const item = (to: string, label: string) => (
    <Link to={to} className={"flex-1 text-center py-2 " + (pathname===to ? "text-brand-dark font-medium" : "text-gray-500")}>{label}</Link>
  )
  return (
    <nav className="fixed bottom-0 left-0 right-0 md:hidden bg-white border-t flex">
      {item('/','Home')}{item('/browse','Browse')}{item('/tasks/new','Ask')}{item('/messages','Chat')}{item('/profile','Me')}
    </nav>
  )
}
