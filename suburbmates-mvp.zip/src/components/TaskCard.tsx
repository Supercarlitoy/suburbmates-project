import { Link } from 'react-router-dom'
export default function TaskCard({task}:{task:{id:string,title:string,suburb:string,budget:number,posted:string}}){
  return (
    <Link to={`/tasks/${task.id}`} className="block bg-white rounded-2xl shadow-sm border p-4 hover:shadow-md transition">
      <div className="flex items-start justify-between">
        <h3 className="font-semibold">{task.title}</h3>
        <span className="text-brand-dark font-semibold">${"{task.budget}"}</span>
      </div>
      <div className="mt-1 text-sm text-gray-600">{task.suburb} • {task.posted}</div>
    </Link>
  )
}
