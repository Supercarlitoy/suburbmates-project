export default {
  content: ['./index.html','./src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: { brand: { primary:'#1B9C85', accent:'#F7B733', dark:'#0f3e36' } },
      borderRadius: { xl:'1rem','2xl':'1.25rem' }
    }
  },
  plugins: []
}
