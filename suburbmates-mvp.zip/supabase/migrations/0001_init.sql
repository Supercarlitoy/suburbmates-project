CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS public.profiles (
  id uuid PRIMARY KEY,
  display_name text,
  photo_url text,
  suburb text,
  bio text,
  role text DEFAULT 'user' CHECK (role IN ('user','support','moderator','owner')),
  verification_level smallint DEFAULT 0,
  rating_avg numeric,
  rating_count int DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.tasks (
  id bigserial PRIMARY KEY,
  owner_id uuid REFERENCES public.profiles(id) ON DELETE CASCADE,
  title text NOT NULL,
  description text NOT NULL,
  category text NOT NULL,
  suburb text NOT NULL,
  budget numeric NOT NULL,
  status text NOT NULL DEFAULT 'open' CHECK (status IN ('open','booked','completed','cancelled','disputed')),
  expires_at timestamptz DEFAULT (now() + interval '14 days'),
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.offers (
  id bigserial PRIMARY KEY,
  task_id bigint REFERENCES public.tasks(id) ON DELETE CASCADE,
  bidder_id uuid REFERENCES public.profiles(id) ON DELETE CASCADE,
  amount numeric NOT NULL,
  message text NOT NULL,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','accepted','rejected','withdrawn','expired')),
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.bookings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  task_id bigint REFERENCES public.tasks(id) ON DELETE CASCADE,
  offer_id bigint REFERENCES public.offers(id) ON DELETE CASCADE,
  provider_id uuid REFERENCES public.profiles(id) ON DELETE CASCADE,
  start_at timestamptz,
  payment_status text DEFAULT 'captured' CHECK (payment_status IN ('pending','authorized','captured','refunded')),
  status text DEFAULT 'scheduled' CHECK (status IN ('scheduled','in_progress','completed','cancelled','disputed')),
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  thread_id uuid NOT NULL,
  sender_id uuid REFERENCES public.profiles(id) ON DELETE CASCADE,
  recipient_id uuid REFERENCES public.profiles(id) ON DELETE CASCADE,
  task_id bigint REFERENCES public.tasks(id),
  text text NOT NULL,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.reviews (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  booking_id uuid REFERENCES public.bookings(id) ON DELETE CASCADE,
  reviewer_id uuid REFERENCES public.profiles(id) ON DELETE CASCADE,
  reviewee_id uuid REFERENCES public.profiles(id) ON DELETE CASCADE,
  rating smallint CHECK (rating BETWEEN 1 AND 5),
  comment text,
  created_at timestamptz DEFAULT now(),
  UNIQUE(booking_id, reviewer_id)
);

CREATE TABLE IF NOT EXISTS public.flags (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  target_type text CHECK (target_type IN ('task','message','profile')),
  target_id uuid,
  reporter_id uuid REFERENCES public.profiles(id),
  reason text NOT NULL,
  status text CHECK (status IN ('open','dismissed','actioned')) DEFAULT 'open',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.verification_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES public.profiles(id) NOT NULL,
  kind text CHECK (kind IN ('identity_address')) NOT NULL,
  status text CHECK (status IN ('pending','approved','rejected','refunded')) DEFAULT 'pending',
  evidence jsonb NOT NULL,
  reviewed_by uuid REFERENCES public.profiles(id),
  reviewed_at timestamptz,
  notes text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.payments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  booking_id uuid REFERENCES public.bookings(id) UNIQUE,
  stripe_payment_intent text NOT NULL,
  amount_cents int NOT NULL,
  platform_fee_cents int NOT NULL,
  status text CHECK (status IN ('authorized','captured','refunded','partially_refunded','on_hold')) NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.payouts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  booking_id uuid REFERENCES public.bookings(id) UNIQUE,
  provider_id uuid REFERENCES public.profiles(id) NOT NULL,
  amount_cents int NOT NULL,
  status text CHECK (status IN ('pending_release','released','held','failed')) DEFAULT 'pending_release',
  released_at timestamptz,
  notes text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.audit_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  actor_id uuid REFERENCES public.profiles(id),
  action text NOT NULL,
  target_type text NOT NULL,
  target_id uuid,
  meta jsonb,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.site_settings (
  key text PRIMARY KEY,
  value jsonb NOT NULL,
  updated_by uuid REFERENCES public.profiles(id),
  updated_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_tasks_status_suburb ON public.tasks(status, suburb);
CREATE INDEX IF NOT EXISTS idx_offers_task ON public.offers(task_id);
CREATE INDEX IF NOT EXISTS idx_messages_thread ON public.messages(thread_id);
CREATE INDEX IF NOT EXISTS idx_flags_status ON public.flags(status);
