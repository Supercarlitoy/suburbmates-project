# SuburbMates Marketplace Policy Pack

## Confidentiality
- No phone numbers, emails, or addresses in tasks, offers, or messages until booking.
- Suburb-only location until booking is confirmed.
- Safe images (no visible addresses/plates).

## Bidding
- One active offer per task per neighbour.
- Price talks via offers only; no undercutting in chat.
- Offers expire after 7 days.

## No Outside Communication
- Contact details blocked until booking/payment is confirmed.

## No Direct Payment
- Platform (Stripe) payments only; bypass attempts may lead to suspension.

## Payout Release (Escrow‑Lite)
- Payment captured on accept; payout released on owner confirmation.
- Auto-complete after 3 days of no response.
- Disputes = hold payout until admin resolution.
