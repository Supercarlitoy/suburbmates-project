# Admin Handbook

Roles: owner, moderator, support.

Queues:
- Flags → review → dismiss/remove/ban
- Verification → approve/reject/refund
- Payouts → release/hold

Settings:
- service_fee_percent, badge_price_cents, offer_expiry_days, auto_complete_days

All actions logged in `audit_logs`.
