# SuburbMates (MVP)
Neighbour‑to‑neighbour local task marketplace for Melbourne — mobile‑first, trust‑first.

## Tech
- React + Vite + TypeScript
- Tailwind CSS
- React Router
- Supabase (Auth + DB + Storage)
- Vercel Serverless (API)
- Stripe (standard payments)
- Resend (emails)

## Quick Start
```bash
npm i
cp .env.example .env
npm run dev
```
