import { Link, useParams } from 'react-router-dom'
export default function TaskDetail(){
  const { id } = useParams()
  const task={id,title:'Assemble flat-pack shelves',suburb:'Fitzroy',budget:80,posted:'2h ago',description:'Need help assembling IKEA Kallax and wall-mounting.'}
  return (
    <div className="mx-auto max-w-3xl px-4 py-6">
      <div className="flex items-start justify-between">
        <h1 className="text-xl font-bold">{task.title}</h1>
        <span className="text-brand-dark font-semibold">${"{task.budget}"}</span>
      </div>
      <div className="text-sm text-gray-600">{task.suburb} • {task.posted}</div>
      <p className="mt-4 text-gray-800">{task.description}</p>
      <div className="mt-6">
        <Link to={`/offers/123`} className="px-4 py-2 rounded-xl bg-brand-primary text-white">Put Your Hand Up</Link>
      </div>
    </div>
  )
}
