export default function Offers(){return(<div className='mx-auto max-w-xl px-4 py-6'><h1 className='text-xl font-bold mb-4'>Put Your Hand Up</h1><p>Offer form goes here (amount + message).</p></div>)}
