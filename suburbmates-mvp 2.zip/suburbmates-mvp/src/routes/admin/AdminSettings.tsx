export default function AdminSettings(){
  return (
    <form className="bg-white border rounded-2xl p-4 space-y-3">
      <div><label className="text-sm font-medium">Service fee (%)</label><input className="w-full border rounded-xl px-3 py-2" defaultValue={10}/></div>
      <div><label className="text-sm font-medium">Badge price (AUD)</label><input className="w-full border rounded-xl px-3 py-2" defaultValue={15}/></div>
      <div><label className="text-sm font-medium">Offer expiry (days)</label><input className="w-full border rounded-xl px-3 py-2" defaultValue={7}/></div>
      <div><label className="text-sm font-medium">Auto-complete (days)</label><input className="w-full border rounded-xl px-3 py-2" defaultValue={3}/></div>
      <button className="px-4 py-2 rounded-xl bg-brand-primary text-white">Save</button>
    </form>
  )
}
