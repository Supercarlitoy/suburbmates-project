export default function AdminPayments(){return(<div className='bg-white border rounded-2xl p-4'>Payments ledger…</div>)}
