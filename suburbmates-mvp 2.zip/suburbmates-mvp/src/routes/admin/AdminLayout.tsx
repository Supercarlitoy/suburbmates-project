import { Outlet, Link, useLocation } from 'react-router-dom'
export default function AdminLayout(){
  const { pathname } = useLocation()
  const Tab = ({to,label}:{to:string,label:string}) => (
    <Link to={to} className={"px-3 py-2 rounded-lg "+(pathname===to?"bg-brand-primary text-white":"bg-white border")}>{label}</Link>
  )
  return (
    <div className="mx-auto max-w-6xl px-4 py-6">
      <h1 className="text-xl font-bold mb-4">Admin Panel</h1>
      <div className="flex gap-2 mb-4 overflow-auto">
        <Tab to="/admin" label="Dashboard"/><Tab to="/admin/users" label="Users"/><Tab to="/admin/tasks" label="Tasks"/>
        <Tab to="/admin/offers" label="Offers"/><Tab to="/admin/flags" label="Flags"/><Tab to="/admin/verification" label="Verification"/>
        <Tab to="/admin/payouts" label="Payouts"/><Tab to="/admin/payments" label="Payments"/><Tab to="/admin/settings" label="Settings"/><Tab to="/admin/reports" label="Reports"/>
      </div>
      <Outlet/>
    </div>
  )
}
