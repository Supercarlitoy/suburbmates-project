export default function Privacy(){
  return (
    <div className="mx-auto max-w-3xl px-4 py-6 prose">
      <h1>Privacy Policy</h1>
      <p>We respect your privacy. We only collect what’s needed to run SuburbMates.</p>
      <ul>
        <li>Suburb‑only location is shown publicly; exact address remains private until booking.</li>
        <li>Messages are scanned for contact details prior to booking to keep everyone safe.</li>
        <li>We don't sell your data.</li>
      </ul>
    </div>
  )
}
