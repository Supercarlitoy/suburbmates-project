import { Routes, Route, Navigate } from 'react-router-dom'
import Home from './routes/Home'
import Browse from './routes/Browse'
import TaskDetail from './routes/TaskDetail'
import NewTask from './routes/NewTask'
import Offers from './routes/Offers'
import Messages from './routes/Messages'
import Dashboard from './routes/Dashboard'
import Profile from './routes/Profile'
import PublicProfile from './routes/PublicProfile'
import Terms from './routes/Terms'
import Privacy from './routes/Privacy'
import AdminLayout from './routes/admin/AdminLayout'
import AdminDashboard from './routes/admin/AdminDashboard'
import AdminUsers from './routes/admin/AdminUsers'
import AdminTasks from './routes/admin/AdminTasks'
import AdminOffers from './routes/admin/AdminOffers'
import AdminFlags from './routes/admin/AdminFlags'
import AdminVerification from './routes/admin/AdminVerification'
import AdminPayouts from './routes/admin/AdminPayouts'
import AdminPayments from './routes/admin/AdminPayments'
import AdminSettings from './routes/admin/AdminSettings'
import AdminReports from './routes/admin/AdminReports'

import Navbar from './components/Navbar'
import BottomNav from './components/BottomNav'

export default function App(){
  return(
    <div className="min-h-screen">
      <Navbar/>
      <main className="pb-20">
        <Routes>
          <Route path="/" element={<Home/>}/>
          <Route path="/browse" element={<Browse/>}/>
          <Route path="/tasks/new" element={<NewTask/>}/>
          <Route path="/tasks/:id" element={<TaskDetail/>}/>
          <Route path="/offers/:id" element={<Offers/>}/>
          <Route path="/messages/*" element={<Messages/>}/>
          <Route path="/dashboard" element={<Dashboard/>}/>
          <Route path="/profile" element={<Profile/>}/>
          <Route path="/u/:username" element={<PublicProfile/>}/>
          <Route path="/legal/terms" element={<Terms/>}/>
          <Route path="/legal/privacy" element={<Privacy/>}/>
          <Route path="/admin" element={<AdminLayout/>}>
            <Route index element={<AdminDashboard/>}/>
            <Route path="users" element={<AdminUsers/>}/>
            <Route path="tasks" element={<AdminTasks/>}/>
            <Route path="offers" element={<AdminOffers/>}/>
            <Route path="flags" element={<AdminFlags/>}/>
            <Route path="verification" element={<AdminVerification/>}/>
            <Route path="payouts" element={<AdminPayouts/>}/>
            <Route path="payments" element={<AdminPayments/>}/>
            <Route path="settings" element={<AdminSettings/>}/>
            <Route path="reports" element={<AdminReports/>}/>
          </Route>
          <Route path="*" element={<Navigate to='/' replace/>}/>
        </Routes>
      </main>
      <BottomNav/>
    </div>
  )
}
