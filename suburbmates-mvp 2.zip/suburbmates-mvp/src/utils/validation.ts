import { z } from 'zod'
export const TaskSchema=z.object({title:z.string().min(8).max(80),description:z.string().min(20).max(1200),category:z.string().min(2),suburb:z.string().min(2),budget:z.number().min(5).max(10000),photos:z.array(z.string().url()).max(3).optional()})
export const OfferSchema=z.object({amount:z.number().min(5).max(10000),message:z.string().min(10).max(500)})
