export const POLICY = {
  confidentiality: [
    'No phone numbers, emails, or addresses until booking.',
    'Suburb-only location until booking is confirmed.'
  ],
  bidding: [
    'One active offer per task per neighbour.',
    'Use offers for price chats; no undercutting in chat.',
    'Offers expire after 7 days.'
  ],
  payments: [
    'All payments via SuburbMates (Stripe).',
    '10% service fee funds safety & ops.',
    'Bypassing payments may lead to ban.'
  ],
  payout: [
    'Payment captured on accept; payout released after owner confirms.',
    'Auto-complete & release after 3 days if owner inactive.',
    'Disputes hold payout until admin resolution.'
  ]
}
