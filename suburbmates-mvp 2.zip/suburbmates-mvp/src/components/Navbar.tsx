import { Link } from 'react-router-dom'
export default function Navbar(){
  return (
    <header className="sticky top-0 z-40 bg-white/90 backdrop-blur border-b">
      <div className="mx-auto max-w-6xl px-4 h-14 flex items-center justify-between">
        <Link to="/" className="font-semibold text-brand-dark">SuburbMates</Link>
        <nav className="hidden md:flex gap-6 text-sm">
          <Link to="/browse">See Who’s Helping Out</Link>
          <Link to="/tasks/new">Ask for a Hand</Link>
          <Link to="/messages">Neighbour Chat</Link>
          <Link to="/profile">My Profile</Link>
        </nav>
        <Link to="/tasks/new" className="md:hidden inline-flex items-center px-3 py-1.5 rounded-xl bg-brand-primary text-white text-sm">Ask for a Hand</Link>
      </div>
    </header>
  )
}
