INSERT INTO public.profiles (id, display_name, suburb, role) VALUES
  ('00000000-0000-0000-0000-000000000001','maria','Carlton','user'),
  ('00000000-0000-0000-0000-000000000002','alex','Fitzroy','owner')
ON CONFLICT DO NOTHING;
